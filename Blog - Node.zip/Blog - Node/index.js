
//Modulos//

  const express = require('express');
  const app = express();
  const mongoose = require('mongoose');
  const admin = require('./routes/admin')
  const bodyParser = require('body-parser')
  const handlebars = require('express-handlebars')
  const path = require('path')
  const session = require('express-session')
  const flash = require('connect-flash')

//Configurações

//Sessão
  app.use(session({
    secret: "session",
    resave: true,
    saveUninitialized: true
  }))

  app.use(flash())
//Middleware
  app.use((req,res,next) =>{
    res.locals.success_msg = req.flash("success_msg")
    res.locals.error_msg = req.flash("error_msg")
    next();
  })

//Config BodyParser//
    app.use(bodyParser.urlencoded({extended: false}))
    app.use(bodyParser.json())

  //Config Handlebars//
   
    app.engine('handlebars', handlebars.engine({defaultLayout: 'main'}))
    app.set('view engine', 'handlebars')
  //Config Mongoose//
    mongoose.connect('mongodb+srv://ArthurH1:123@cluster0.l99ymue.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
    .then(() =>{
      console.log('Conectado ao banco')
    }).catch((erro) => {
      console.log(erro)
    })
  //Public
  app.use(express.static(path.join(__dirname, 'public')))


//Rotas
app.use('/admin', admin)

app.get('/', (req,res) =>{
  res.render('admin/index')
})

app.listen(8081,() => {
  console.log('Servidor rodando na porta', 8081)
})